const Products = [
    {
        id: 'ff55f',
        title: 'HP 15 (2021) Thin & Light Ryzen 3-3250 Laptop, 8 GB RAM, 1TB HDD, 39.62 cms (15.6") FHD Screen, Windows 10, MS Office (15s-gr0011AU)',
        price: 523.96,
        rating: 4,
        image: 'https://images-na.ssl-images-amazon.com/images/I/41mQtYQUzmL.jpg'
    },
    {
        id: "123456xsjj",
        title: "Samsung 192 L 2 Star Direct Cool Single Door Refrigerator (RR19A241BGS/NL, Grey Silver)",
        price: 128,
        rating: 4,
        image: 'https://images-na.ssl-images-amazon.com/images/I/81FyYXoQF-L._SL1500_.jpg'
    },
    {
        id: "sfjgjj69",
        title: "Redmi Note 9 Pro (Glacier White, 4GB RAM, 64GB Storage) - Latest 8nm Snapdragon 720G &Alexa Hands-Free Capable",
        price: 152,
        rating: 5,
        image: 'https://images-na.ssl-images-amazon.com/images/I/81fwKtv0VHL._SL1500_.jpg'
    },

    {
        title: "LG 32 L Convection Microwave Oven (MC3286BRUM, Black, With Starter Kit",
        id: "uull66",
        price: 190,
        rating: 4,
        image: 'https://images-na.ssl-images-amazon.com/images/I/91fSgD70z0L._SL1500_.jpg'
    },
    {
        id: "jjjjj55",
        title: "Samsung 192 L 2 Star Direct Cool Single Door Refrigerator (RR19A241BGS/NL, Grey Silver)",
        price: 220,
        rating: 5,
        image: 'https://images-na.ssl-images-amazon.com/images/I/51QmQjHQASL._SL1500_.jpg'
    },
    {
        id: "dektj55",
        title: "Samsung 80 cm (32 I`nches) Wondertainment Series HD Ready LED Smart TV UA32T4340AKXXL (Glossy Black) (2020 Model)",
        price: 450,
        rating: 3,
        image: 'https://images-na.ssl-images-amazon.com/images/I/71fEd9glTIL._SL1500_.jpg'

    }

]
export default Products;